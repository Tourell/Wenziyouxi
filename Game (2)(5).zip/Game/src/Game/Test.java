package Game;

import javax.swing.*;
import java.awt.*;
public class Test {
    public static void main(String[] args) {
        /**
         * ���ñ���ͼ�ͱ���ͼ��͸���ȣ�0Ϊȫ͸����1.0fΪ��͸����
         */
        myJFrame f = new myJFrame("ab.png",0.7f);
 
        f.setLayout(null);
        Font font = new Font("����",Font.PLAIN,30);
        JLabel user = new JLabel("�û���");
        user.setFont(font);
        user.setBounds(100,150,100,30);
        JTextField userInput = new JTextField();
        userInput.setFont(font);
        userInput.setBounds(200,145,250,40);
        JLabel ps = new JLabel("����");
        ps.setFont(font);
        ps.setBounds(110,200,90,30);
        JTextField psInput = new JTextField();
        psInput.setFont(font);
        psInput.setBounds(200,195,250,40);
 
        f.add(user);
        f.add(userInput);
        f.add(ps);
        f.add(psInput);
        f.setLocation(300,100);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);
    }
}
