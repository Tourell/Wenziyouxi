/*
 * ��������.java
 *
 * Created on __DATE__, __TIME__
 */

package Game;

import java.awt.Color;
import java.awt.Container;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author  __USER__
 */
public class citybegin extends javax.swing.JFrame {

	/** Creates new form �������� */
	public citybegin() {
		initComponents();
		this.setResizable(false);

		this.setLocationRelativeTo(null);
		setBak(); //���ñ�������
		Container c = getContentPane(); //��ȡJFrame���
		JPanel jp = new javax.swing.JPanel();

		jp.setOpaque(false);
		c.add(jp);
		setSize(5400, 4500);
		setVisible(true);

		initComponents();
	}

	private void setBak() {
		// TODO Auto-generated method stub
		((JPanel) this.getContentPane()).setOpaque(false);
		ImageIcon img = new ImageIcon("img/liubei.jpg"); //����ͼƬ
		JLabel background = new JLabel(img);
		this.getLayeredPane().add(background, new Integer(Integer.MIN_VALUE));
		background.setBounds(0, 0, img.getIconWidth(), img.getIconHeight());
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jPanel1 = new javax.swing.JPanel();
		jPanel1.setOpaque(false);
		jButton1 = new javax.swing.JButton();
		jLabel2 = new javax.swing.JLabel();
		jButton4 = new javax.swing.JButton();
		jLabel1 = new javax.swing.JLabel();
		jLabel3 = new javax.swing.JLabel();
		jLabel4 = new javax.swing.JLabel();
		jLabel5 = new javax.swing.JLabel();
		jLabel6 = new javax.swing.JLabel();
		jLabel7 = new javax.swing.JLabel();
		jLabel8 = new javax.swing.JLabel();
		jLabel9 = new javax.swing.JLabel();
		jLabel10 = new javax.swing.JLabel();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jButton1.setBackground(new java.awt.Color(204, 204, 204));
		jButton1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jButton1.setText("\u8bbe\u7f6e");
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});

		jLabel2.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jLabel2.setForeground(new java.awt.Color(255, 255, 0));
		jLabel2
				.setText("m\u96c6\u56e2\u8463\u4e8b\u957f\uff0c\u8eab\u4ef7\u8fc7\u4ebf\uff0c\u6027\u683c\u66b4\u8e81\uff0c\u597d\u5973\u8272\uff0c\u8eab\u8fb9\u7684\u670b\u53cb\u5bf9\u4ed6\u90fd\u4e0d\u597d\uff0c\u559c\u6b22\u559d\u9152\u62bd\u70df\uff0c");

		jButton4.setBackground(new java.awt.Color(204, 204, 204));
		jButton4.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jButton4.setText("\u4e0b\u4e00\u6b65");
		jButton4.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton4ActionPerformed(evt);
			}
		});

		jLabel1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jLabel1.setForeground(new java.awt.Color(255, 255, 0));
		jLabel1
				.setText("\u6bcf\u5929\u90fd\u5f88\u665a\u56de\u5bb6\u3002\u6b7b\u8005\u6b7b\u5728\u5bb6\u4e2d\uff0c\u7ecf\u9a8c\u5c38\u5b98\u8bf4\uff0c\u6b7b\u8005\u662f\u4e2d\u6bd2\uff0c\u5fc3\u810f\u8870\u7aed\u800c\u6b7b\uff0c\u8eab\u4e0a\u6709\u591a\u5904");

		jLabel3.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jLabel3.setForeground(new java.awt.Color(255, 255, 0));
		jLabel3
				.setText("\u4f24\u53e3\uff0c\u8111\u540e\u6709\u4e00\u5904\u91cd\u7269\u6572\u51fb\u7684\u4f24\u53e3\uff0c\u4f3c\u4e4e\u751f\u524d\u548c\u522b\u4eba\u6253\u8fc7\u67b6\u3002\u5728\u5176\u8863\u7269\u4e2d\u53d1\u73b0\u9152\u5427\u6d88\u8d39");

		jLabel4.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jLabel4.setForeground(new java.awt.Color(255, 255, 0));
		jLabel4
				.setText("\u5355\uff0c\u4e00\u6761\u624b\u5e15\uff0c\u94b1\u5305\uff08\u94b1\u5305\u4e2d\u7684\u91d1\u94b1\u5168\u90e8\u88ab\u62ff\u8d70\u4e86\uff09\u3002\u6307\u7532\u4e2d\u5e26\u70b9\u8840\u8ff9\u3002\u7ecf\u68c0\u9a8c\uff0c\u6b7b\u8005\u662f");

		jLabel5.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jLabel5.setForeground(new java.awt.Color(255, 255, 0));
		jLabel5
				.setText("\u6b7b\u5728\u51cc\u66681\u70b9\uff0c\u5728\u88ab\u53d1\u73b0\u6b7b\u4ea1\u65f6\u662f\u65e9\u4e0a10\u70b9\u3002\u53d1\u73b0\u5bb6\u91cc\u5f88\u51cc\u4e71\uff0c\u6709\u6253\u67b6\u7684\u75d5\u8ff9\u3002\u5ba2\u5385\u684c\u5b50");

		jLabel6.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jLabel6.setForeground(new java.awt.Color(255, 255, 0));
		jLabel6
				.setText("\u4e0a\u6709\u4e00\u74f6\u9152\u548c\u4e00\u4e2a\u9152\u676f\uff0c\u7ecf\u68c0\u9a8c\uff0c\u9152\u676f\u53e3\u5904\u6709\u6bd2\u836f\u7684\u75d5\u8ff9\u3002\u5ba2\u5385\u9633\u53f0\u7684\u843d\u5730\u7a97\u662f\u5f00\u7740\u7684\u3002");

		jLabel7.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jLabel7.setForeground(new java.awt.Color(255, 255, 0));
		jLabel7
				.setText("\u5218\u5907\u4f4f\u57282\u697c\u3002\u5218\u5907\u6b7b\u540e\u6709\u62d6\u52a8\u5c38\u4f53\u7684\u75d5\u8ff9\uff0c\u4f3c\u4e4e\u4ed6\u662f\u5728\u5ba2\u5385\u6b7b\u7684\uff0c\u4f46\u88ab\u51f6\u624b\u62d6\u8fdb\u4e86\u6d74\u5ba4\uff0c");

		jLabel8.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jLabel8.setForeground(new java.awt.Color(255, 255, 0));
		jLabel8
				.setText("\u800c\u4e14\u6d74\u5ba4\u7684\u55b7\u6d12\u662f\u5f00\u7740\u7684\uff0c\u4e00\u76f4\u51b2\u7740\u6b7b\u8005\u3002\u5728\u5218\u5907\u7535\u8111\u91cc\u53d1\u73b0\u79d8\u5bc6\u6587\u4ef6\uff0c\u662f\u5173\u4e8em\u96c6\u56e2\u6536");

		jLabel9.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jLabel9.setForeground(new java.awt.Color(255, 255, 0));
		jLabel9
				.setText("\u8d2dk\u516c\u53f8\u7684\u3002\u53d1\u73b0\u5218\u5907\u7684\u5e8a\u4e0a\u6709\u5973\u4eba\u7684\u5934\u53d1\uff0c\u68c0\u9a8c\u662f\u5c0f\u4e54\u7684\u3002\u5f88\u663e\u7136\u8fd9\u4e0d\u662f\u5218\u5907\u771f\u6b63\u7684\u5bb6\uff0c");

		jLabel10.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jLabel10.setForeground(new java.awt.Color(255, 255, 0));
		jLabel10.setText("\u53ea\u662f\u4ed6\u4e00\u4e2a\u4f4f\u6240\u3002");

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout
				.setHorizontalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																jPanel1Layout
																		.createSequentialGroup()
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.TRAILING)
																						.addComponent(
																								jLabel10,
																								javax.swing.GroupLayout.Alignment.LEADING,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								950,
																								Short.MAX_VALUE)
																						.addComponent(
																								jLabel9,
																								javax.swing.GroupLayout.Alignment.LEADING,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								950,
																								Short.MAX_VALUE)
																						.addComponent(
																								jLabel8,
																								javax.swing.GroupLayout.Alignment.LEADING,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								950,
																								Short.MAX_VALUE)
																						.addComponent(
																								jLabel7,
																								javax.swing.GroupLayout.Alignment.LEADING,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								Short.MAX_VALUE)
																						.addComponent(
																								jLabel6,
																								javax.swing.GroupLayout.Alignment.LEADING,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								950,
																								Short.MAX_VALUE)
																						.addComponent(
																								jLabel5,
																								javax.swing.GroupLayout.Alignment.LEADING,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								950,
																								Short.MAX_VALUE)
																						.addComponent(
																								jLabel3,
																								javax.swing.GroupLayout.Alignment.LEADING,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								950,
																								Short.MAX_VALUE)
																						.addComponent(
																								jLabel1,
																								javax.swing.GroupLayout.Alignment.LEADING,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								950,
																								Short.MAX_VALUE)
																						.addComponent(
																								jLabel2,
																								javax.swing.GroupLayout.Alignment.LEADING,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								950,
																								Short.MAX_VALUE)
																						.addComponent(
																								jLabel4,
																								javax.swing.GroupLayout.Alignment.LEADING,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								950,
																								Short.MAX_VALUE))
																		.addGap(
																				344,
																				344,
																				344))
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																jPanel1Layout
																		.createSequentialGroup()
																		.addComponent(
																				jButton4,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				118,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addGap(
																				113,
																				113,
																				113))
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																jPanel1Layout
																		.createSequentialGroup()
																		.addComponent(
																				jButton1,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				118,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addGap(
																				94,
																				94,
																				94)))));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(
												jButton1,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												59,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(6, 6, 6)
										.addComponent(
												jLabel2,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												48,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jLabel1,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												51,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jLabel3,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												52,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jLabel4,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												48,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jLabel5,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												55,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jLabel6,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												45,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jLabel7,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												46,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jLabel8,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												42,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jLabel9,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												44,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jLabel10,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												47,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jButton4,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												59,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap(
												javax.swing.GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				layout.createSequentialGroup().addContainerGap().addComponent(
						jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE,
						javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addContainerGap()));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				javax.swing.GroupLayout.Alignment.TRAILING,
				layout.createSequentialGroup().addContainerGap().addComponent(
						jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE,
						javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addContainerGap()));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {
		new diaocheduixiangcity().setVisible(true);
		this.dispose();
	}

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
		new set(this).setVisible(true);
		this.hide();
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new citybegin().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton4;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel10;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JLabel jLabel7;
	private javax.swing.JLabel jLabel8;
	private javax.swing.JLabel jLabel9;
	private javax.swing.JPanel jPanel1;
	// End of variables declaration//GEN-END:variables

}