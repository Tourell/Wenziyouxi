/*
 * xiaoqiao4.java
 *
 * Created on __DATE__, __TIME__
 */

package Game;

import java.awt.Color;
import java.awt.Container;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author  __USER__
 */
public class xiaoqiao4 extends javax.swing.JFrame {

	/** Creates new form xiaoqiao4 */
	public xiaoqiao4() {
		initComponents();
		this.setResizable(false);

		this.setLocationRelativeTo(null);
		setBak(); //���ñ�������
		Container c = getContentPane(); //��ȡJFrame���
		JPanel jp = new javax.swing.JPanel();

		jp.setOpaque(false);
		c.add(jp);
		setSize(5400, 4500);
		setVisible(true);

		initComponents();
	}

	private void setBak() {
		// TODO Auto-generated method stub
		((JPanel) this.getContentPane()).setOpaque(false);
		ImageIcon img = new ImageIcon("img/xiaoqiao.jpg"); //����ͼƬ
		JLabel background = new JLabel(img);
		this.getLayeredPane().add(background, new Integer(Integer.MIN_VALUE));
		background.setBounds(0, 0, img.getIconWidth(), img.getIconHeight());
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jPanel1 = new javax.swing.JPanel();
		jPanel1.setOpaque(false);
		jButton1 = new javax.swing.JButton();
		jButton2 = new javax.swing.JButton();
		jLabel1 = new javax.swing.JLabel();
		jButton8 = new javax.swing.JButton();
		jButton8.setOpaque(false);
		jButton7 = new javax.swing.JButton();
		jButton7.setOpaque(false);
		jButton6 = new javax.swing.JButton();
		jButton6.setOpaque(false);

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jButton1.setBackground(new java.awt.Color(204, 204, 204));
		jButton1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jButton1.setText("\u8bbe\u7f6e");
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});

		jButton2.setBackground(new java.awt.Color(204, 204, 204));
		jButton2.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jButton2.setText("\u8bc1\u636e");
		jButton2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton2ActionPerformed(evt);
			}
		});

		jLabel1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 36));
		jLabel1.setForeground(new java.awt.Color(51, 51, 255));
		jLabel1
				.setText("2.\u4f60\u6628\u665a\u5728\u54ea\u91cc\uff0c\u5e72\u4e86\u4ec0\u4e48\uff1f");

		jButton8.setBackground(new java.awt.Color(204, 204, 204));
		jButton8.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jButton8.setForeground(new java.awt.Color(51, 51, 255));
		jButton8
				.setText("\u6628\u665a\u521a\u597d\u6211\u52a0\u73ed\u4e0b\u73ed\uff0c\u5f53\u65f6\u662f10\u70b9\u534a\uff0c\u6211\u56de\u5230\u5bb6\u7684\u65f6\u5019\uff0c\u662f11\u70b9\u949f\uff0c\u5f53\u65f6\u6211\u5f88\u7d2f\uff0c\u4e8e\u662f\u6fa1\u90fd\u6ca1\u6d17\u4fbf\u5012\u5934\u5c31\u7761");
		jButton8.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton8ActionPerformed(evt);
			}
		});

		jButton7.setBackground(new java.awt.Color(204, 204, 204));
		jButton7.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jButton7.setForeground(new java.awt.Color(51, 51, 255));
		jButton7
				.setText("\u6211\u6628\u665a\u56de\u6765\u770b\u4e86\u4f1a\u7535\u89c6\uff0c\u7136\u540e\u5c31\u7761\u89c9\u4e86");
		jButton7.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton7ActionPerformed(evt);
			}
		});

		jButton6.setBackground(new java.awt.Color(204, 204, 204));
		jButton6.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jButton6.setForeground(new java.awt.Color(51, 51, 255));
		jButton6.setText("\u8df3\u8fc7\u6b64\u95ee\u9898");
		jButton6.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton6ActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout
				.setHorizontalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGap(
																				27,
																				27,
																				27)
																		.addComponent(
																				jLabel1,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				894,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGap(
																				994,
																				994,
																				994)
																		.addComponent(
																				jButton2,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				118,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addGap(
																				84,
																				84,
																				84)
																		.addComponent(
																				jButton1,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				118,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGap(
																				103,
																				103,
																				103)
																		.addComponent(
																				jButton8)))
										.addContainerGap(
												javax.swing.GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE))
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel1Layout.createSequentialGroup()
										.addContainerGap(491, Short.MAX_VALUE)
										.addComponent(jButton7).addGap(397,
												397, 397))
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel1Layout
										.createSequentialGroup()
										.addContainerGap(618, Short.MAX_VALUE)
										.addComponent(
												jButton6,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												176,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(535, 535, 535)));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jButton1,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																59,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																jButton2,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																59,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(41, 41, 41)
										.addComponent(
												jLabel1,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												91,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(31, 31, 31)
										.addComponent(
												jButton8,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												82,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												101, Short.MAX_VALUE)
										.addComponent(
												jButton7,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												97,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(91, 91, 91)
										.addComponent(
												jButton6,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												97,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap()));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGap(0, 1344,
				Short.MAX_VALUE).addGap(0, 1344, Short.MAX_VALUE).addGap(0,
				1344, Short.MAX_VALUE).addGap(0, 1344, Short.MAX_VALUE).addGap(
				0, 1344, Short.MAX_VALUE).addGap(0, 1344, Short.MAX_VALUE)
				.addGap(0, 1344, Short.MAX_VALUE).addGap(0, 1344,
						Short.MAX_VALUE).addGap(0, 1344, Short.MAX_VALUE)
				.addGap(0, 1344, Short.MAX_VALUE).addGap(0, 1344,
						Short.MAX_VALUE).addGap(0, 1344, Short.MAX_VALUE)
				.addGap(0, 1344, Short.MAX_VALUE).addGap(0, 1344,
						Short.MAX_VALUE).addGroup(
						layout.createSequentialGroup().addComponent(jPanel1,
								javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.PREFERRED_SIZE)
								.addContainerGap(
										javax.swing.GroupLayout.DEFAULT_SIZE,
										Short.MAX_VALUE)));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGap(0, 738,
				Short.MAX_VALUE).addGap(0, 738, Short.MAX_VALUE).addGap(0, 738,
				Short.MAX_VALUE).addGap(0, 738, Short.MAX_VALUE).addGap(0, 738,
				Short.MAX_VALUE).addGap(0, 738, Short.MAX_VALUE).addGap(0, 738,
				Short.MAX_VALUE).addGap(0, 738, Short.MAX_VALUE).addGap(0, 738,
				Short.MAX_VALUE).addGap(0, 738, Short.MAX_VALUE).addGap(0, 738,
				Short.MAX_VALUE).addGap(0, 738, Short.MAX_VALUE).addGap(0, 738,
				Short.MAX_VALUE).addGap(0, 738, Short.MAX_VALUE).addGroup(
				layout.createSequentialGroup().addComponent(jPanel1,
						javax.swing.GroupLayout.PREFERRED_SIZE,
						javax.swing.GroupLayout.DEFAULT_SIZE,
						javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE,
								Short.MAX_VALUE)));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {
		new xiaoqiao5().setVisible(true);
		this.dispose();
	}

	private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {
		new xiaoqiao5().setVisible(true);
		this.dispose();
	}

	private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {
		new xiaoqiao5().setVisible(true);
		this.dispose();
	}

	private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
		new set(this).setVisible(true);
		this.hide();
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new xiaoqiao4().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton2;
	private javax.swing.JButton jButton6;
	private javax.swing.JButton jButton7;
	private javax.swing.JButton jButton8;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JPanel jPanel1;
	// End of variables declaration//GEN-END:variables

}