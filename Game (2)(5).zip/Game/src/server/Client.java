package server;


import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

import model.User;

public class Client {

	ObjectOutputStream oos;
	ObjectInputStream ois;

	final int LOGIN = 1001;//��¼
	final int REGISTER = 1002;//ע��
	final int BACKGROUND = 1003;//����
	final int INVESTIGATION = 1004;//����
	final int EVIDENCE = 1005;//֤��
	final int CONFESSION = 1006;//�ڹ�
	final int CASEREDUCTION =1007;//������ԭ
	
	
	
	
	
	
	public Client() throws UnknownHostException, IOException {
		Socket s;
		s = new Socket("10.51.163.254",23456);
		System.out.println("�ͻ������ӷ�����");
		
		oos = new ObjectOutputStream(s.getOutputStream());
		ois = new ObjectInputStream(s.getInputStream());
	}
	
	public User login(String uname,String upw) throws IOException, ClassNotFoundException{
		//��¼
		oos.writeInt(LOGIN);
		oos.flush();
		
		oos.writeUTF(uname);
		oos.flush();
		
		oos.writeUTF(upw);
		oos.flush();
		
		return (User) ois.readObject();
	}
	public  User register(String uname,String upw,String uemail) throws IOException, ClassNotFoundException{
		//ע��
		oos.writeInt(REGISTER);
		oos.flush();
		oos.writeUTF(uname);
		oos.flush();
		oos.writeUTF(upw);
		oos.flush();
		oos.writeUTF(uemail);
		oos.flush();
		return (User) ois.readObject();
	}
public String investigation(int id) throws IOException{
		//����
	
		oos.writeInt(INVESTIGATION);
		oos.flush();
		oos.write(id);
	oos.flush();
	return ois.readUTF();
	}
public String background(int id) throws IOException{
	//����
	oos.writeInt(BACKGROUND);
	oos.flush();
	return ois.readUTF();
	
}
public String confession(int id) throws IOException{
	//�ڹ�
	oos.writeInt(CONFESSION);
	oos.flush();
	
	return ois.readUTF();
}

public String caseReduction(int id) throws IOException, ClassNotFoundException{
	//������ԭ
	oos.writeInt(CASEREDUCTION);
	oos.flush();
	
	return ois.readUTF();
}
public String evidence(int id) throws IOException, ClassNotFoundException{
	//֤��
	oos.writeInt(EVIDENCE);
	oos.flush();
	
	return ois.readUTF();
}

	
}
