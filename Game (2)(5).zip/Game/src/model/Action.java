package model;

public class Action {
	
	private int aid;
	private String action;
	private String score;
	public Action(int aid, String action, String score) {
		super();
		this.aid = aid;
		this.action = action;
		this.score = score;
	}
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	
}
