package model;

public class Role {
	
	private int roleid;
	private String rolename;
	private String roledescriptiong;
	public Role(int roleid, String rolename, String roledescriptiong) {
		super();
		this.roleid = roleid;
		this.rolename = rolename;
		this.roledescriptiong = roledescriptiong;
	}
	public int getRoleid() {
		return roleid;
	}
	public void setRoleid(int roleid) {
		this.roleid = roleid;
	}
	public String getRolename() {
		return rolename;
	}
	public void setRolename(String rolename) {
		this.rolename = rolename;
	}
	public String getRoledescriptiong() {
		return roledescriptiong;
	}
	public void setRoledescriptiong(String roledescriptiong) {
		this.roledescriptiong = roledescriptiong;
	}

	
}
