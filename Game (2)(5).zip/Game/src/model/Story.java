package model;

public class Story {
	
	private int storyid;
	private String storyname;
	public Story(int storyid, String storyname) {
		super();
		this.storyid = storyid;
		this.storyname = storyname;
	}
	public int getStoryid() {
		return storyid;
	}
	public void setStoryid(int storyid) {
		this.storyid = storyid;
	}
	public String getStoryname() {
		return storyname;
	}
	public void setStoryname(String storyname) {
		this.storyname = storyname;
	}
	
	
	
	
}
