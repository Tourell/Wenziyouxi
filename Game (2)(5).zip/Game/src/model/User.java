package model;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Statement;

public class User implements Serializable{
	
	private int uid;
	private String upw;
	private String uname;
	private String uemail;
	private int uscore;
	private boolean islogin;
	public User(){
		islogin = false;
	}
	public User(int uid, String upw, String uname, String uemail, int uscore) {
		super();
		this.uid = uid;
		this.upw = upw;
		this.uname = uname;
		this.uemail = uemail;
		this.uscore = uscore;
		islogin = true;
	}
	public boolean islogin(){
		return islogin;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getUpw() {
		return upw;
	}
	public void setUpw(String upw) {
		this.upw = upw;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUemail() {
		return uemail;
	}
	public void setUemail(String uemail) {
		this.uemail = uemail;
	}
	public int getUscore() {
		return uscore;
	}
	public void setUscore(int uscore) {
		this.uscore = uscore;
	}
	//��½
	protected User login(int uid,String upw) throws Exception, ClassNotFoundException{
		String sql ="select * from user where uid ="+uid+" and upw='"+upw+"'";
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		if(rs.next())
			return new User(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));
		return new User();
		
	}
	//ע��
	public void register(int uid, String upw, String uname, String uemail, int uscore) throws SQLException, ClassNotFoundException {
	/*String sql ="select * from user where uid ="+uid;
		ResultSet rs = DatabaseConnect.getStat().executQuery(sql);
		if(rs.next())
			return false;*/
		String sql = "insert into user values("+uid+",'"+uname+"','"+upw+"','"+uemail+"',"+uscore+")";
		Statement stmt=(Statement) DataConnect.getStat();
		stmt.execute(sql);
		
			
	}

	

	/*//���ӵ���
	protected void addfile(int fid,int sid,String file) throws SQLException, ClassNotFoundExpection {
		if(islogin==false)
			return;
		String sql = "insert into file valuse(uid,fid,sid,file)("+uid+","+fid+","+sid+",'"+file+"')";
		DatabaseConnect.getStat().executeUpdate(sql);
	}
	//�浵
	protected void savefile(int fid,int sid,int eid,int rid,int aid,String file) throws SQLException, ClassNotFoundExpection{
		if(islogin==false)
			return;
		String sql = "insert into file valuse("+uid+","+fid+","+sid+","+eid+","+rid+","+aid+",'"+file+"')";
		DatabaseConnect.getStat().executeUpdate(sql);
	}

	//����
	protected void readfile(int fid,int sid,int eid,int rid,int aid) throws SQLException, ClassNotFoundExpection{
		if(islogin==false)
			return;
		String sql = "insert into file valuse("+uid+","+fid+","+sid+","+eid+","+rid+","+aid+")";
		DatabaseConnect.getStat().executeUpdate(sql);
		
	}
	//ɾ��
	protected void deletfile(int fid,int sid)throws SQLException, ClassNotFoundExpection {
		if(islogin==false)
			return;
		String sql = "insert into file valuse("+uid+","+fid+","+sid+")";
		DatabaseConnect.getStat().executeUpdate(sql);
	}*/
	//ע��
	protected User logout(){
		return new User();
	}
	
}
