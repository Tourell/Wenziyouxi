package model;

public class Event {
	
	private int eid;
	private String roleame;
	private String eventdescription;
	public Event(int eid, String roleame, String eventdescription) {
		super();
		this.eid = eid;
		this.roleame = roleame;
		this.eventdescription = eventdescription;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getRoleame() {
		return roleame;
	}
	public void setRoleame(String roleame) {
		this.roleame = roleame;
	}
	public String getEventdescription() {
		return eventdescription;
	}
	public void setEventdescription(String eventdescription) {
		this.eventdescription = eventdescription;
	}
	
}
