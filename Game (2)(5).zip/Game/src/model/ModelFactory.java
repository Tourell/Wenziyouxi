package model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ModelFactory {
	
	static User u = new User();
	protected User login(int uid,String upw) throws Exception, ClassNotFoundException{
		return u.login(uid, upw);
	}
	protected void register(int uid, String upw, String uname, String uemail, int uscore) throws SQLException, ClassNotFoundException {
		u.register(uid, upw, uname, uemail, uscore);
	}
	public static User logout(){
		return u.logout();
	}
	public static String [][][] villageBackgroundStories() throws SQLException, ClassNotFoundException{
		
		ArrayList<String> event = new  ArrayList<String>();
		String sql ="select * from event";
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		while(rs.next())
		{
			event.add(rs.getString(3));
		}
		
		String[][][] villagebgs = new String[10][10][10];
		
		for(int i=0;i<10;i++){
		sql ="select * from event";
		rs = DataConnect.getStat().executeQuery(sql);
		while(rs.next())
		{
			event.add(rs.getString(3));
		}
		}
		
		
		return villagebgs;  
		
		
		
		
	}
	public static void villageBasement(){
		
	}
	public static void villageHu(){
		
	}
	public static void villageLi(){
		
	}
	public static void villageWang(){
		
	}
	public static void cityJoe(){
		
	}
	public static void cityCao(){
		
	}
	public static void cityLiu(){
		
	}
	public static void cityBackgroundStories(){
		
	}
	


}
