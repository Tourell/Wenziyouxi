package model;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;



public class DataConnect {
	private static Connection conn = null;
	private static Statement stmt;
	
	// ȡ�����ݿ�����
	public static Connection getConnection() {
		if (conn != null) {
			return conn;
		}
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://127.0.0.1:3306/game";
		String dbname = "root";
		String pwd = "123456";

		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, dbname,pwd);
			stmt=conn.createStatement();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("�������ݿ�����ʧ�ܣ�");
		}
		return conn;
	}
	public static Statement getStat(){
		if(stmt==null)
			getConnection();
		return stmt;
	} 
}